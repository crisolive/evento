package com.fatec.egresso.controller;

import com.fatec.egresso.entity.Administrador;
import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.repository.EgressoRepository;
import com.fatec.egresso.service.AdministradorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
@SessionAttributes("adminLogado")
public class AdministradorController {

    private final AdministradorService service;
    private final EgressoRepository egressoRepository;

    public AdministradorController(AdministradorService service, EgressoRepository egressoRepository) {
        this.service = service;
        this.egressoRepository = egressoRepository;
    }

    // Página de login
    @GetMapping("/login")
    public String loginForm(Model model) {
        model.addAttribute("admin", new Administrador());
        return "admin/login";
    }

    // Processa o login
    @PostMapping("/login")
    public String realizarLogin(@ModelAttribute Administrador admin, Model model) {
        Administrador encontrado = service.buscarPorEmailESenha(admin.getEmail(), admin.getSenha());

        if (encontrado != null) {
            model.addAttribute("adminLogado", encontrado);
            return "redirect:/admin/menu";
        } else {
            model.addAttribute("erro", "E-mail ou senha inválidos");
            return "admin/login";
        }
    }

    // Tela com o menu do administrador
    @GetMapping("/menu")
    public String menuAdministrador() {
        return "admin/menu";
    }

    // Lista todos os administradores
    @GetMapping("/lista")
    public String listar(Model model, @ModelAttribute("adminLogado") Administrador adminLogado) {
        model.addAttribute("admins", service.listarTodos());
        model.addAttribute("adminLogado", adminLogado); // Garante que adminLogado está disponível
        return "admin/lista";
    }

    // Novo administrador
    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("admin", new Administrador());
        return "admin/form";
    }

    // Salvar administrador
    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Administrador admin, Model model, 
                        @ModelAttribute("adminLogado") Administrador adminLogado) {
        
        // Verifica se está tentando editar outro admin
        if (admin.getId() != null && !admin.getId().equals(adminLogado.getId())) {
            return "redirect:/admin/lista";
        }

        Administrador existente = service.buscarPorEmail(admin.getEmail());

        if (existente != null && (admin.getId() == null || !existente.getId().equals(admin.getId()))) {
            model.addAttribute("error", "Este e-mail já está cadastrado para outro administrador.");
            model.addAttribute("admin", admin);
            return "admin/form";
        }

        try {
            service.salvar(admin);
            return "redirect:/admin/lista";
        } catch (IllegalArgumentException e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("admin", admin);
            return "admin/form";
        }
    }

    // Editar administrador - só permite editar o próprio perfil
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, 
                        @ModelAttribute("adminLogado") Administrador adminLogado) {
        // Verifica se está tentando editar outro admin
        if (!adminLogado.getId().equals(id)) {
            return "redirect:/admin/lista";
        }
        
        Administrador admin = service.buscarPorId(id);
        if (admin == null) {
            return "redirect:/admin/lista";
        }
        model.addAttribute("admin", admin);
        return "admin/form";
    }

    // Excluir administrador - verifica se não está excluindo a si mesmo
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, 
                         @ModelAttribute("adminLogado") Administrador adminLogado) {
        // Impede que um admin se exclua
        if (adminLogado.getId().equals(id)) {
            return "redirect:/admin/lista";
        }
        
        service.excluir(id);
        return "redirect:/admin/lista";
    }

    // Listar egressos pendentes
    @GetMapping("/pendentes")
    public String listarPendentes(Model model) {
        List<Egresso> pendentes = egressoRepository.findByAprovadoFalse();
        model.addAttribute("pendentes", pendentes);
        return "admin/pendentes";
    }

    // Aprovar egresso
    @PostMapping("/aprovar/{id}")
    public String aprovarEgresso(@PathVariable Long id) {
        Optional<Egresso> optional = egressoRepository.findById(id);
        if (optional.isPresent()) {
            Egresso egresso = optional.get();
            egresso.setAprovado(true);
            egressoRepository.save(egresso);
        }
        return "redirect:/admin/pendentes";
    }

    // Deletar egresso com envio de e-mail de rejeição
    @PostMapping("/deletar/{id}")
    public String deletarEgresso(@PathVariable Long id,
                               @RequestParam(required = false) String motivoRejeicao,
                               RedirectAttributes redirectAttributes) {
        Optional<Egresso> optional = egressoRepository.findById(id);
        
        if (optional.isPresent()) {
            Egresso egresso = optional.get();
            String emailEgresso = egresso.getEmail();
            String nomeEgresso = egresso.getNomeCompleto();
            
            String[] motivosPadrao = {
                "Não ser ex-aluno da FATEC",
                "Ainda não ter concluído o curso da FATEC",
                "Não atender aos princípios de ética expostos no termo de aceite",
                "Não colocar uma foto que seja possível reconhecer o egresso"
            };
            
            String motivoFinal = motivoRejeicao != null && !motivoRejeicao.isEmpty() ? 
                              motivoRejeicao : motivosPadrao[0];
            
            boolean emailEnviado = service.enviarEmailRejeicao(
                emailEgresso, nomeEgresso, motivoFinal, motivosPadrao);
            
            if (emailEnviado) {
                redirectAttributes.addFlashAttribute("sucesso", 
                    "Egresso rejeitado e e-mail de notificação enviado com sucesso.");
            } else {
                redirectAttributes.addFlashAttribute("aviso", 
                    "Egresso rejeitado, mas o e-mail não pôde ser enviado.");
            }
            
            egressoRepository.deleteById(id);
        }
        
        return "redirect:/admin/pendentes";
    }

    // Logout do administrador
    @GetMapping("/logout")
    public String logout(SessionStatus status) {
        status.setComplete();
        return "redirect:/admin/login";
    }

    // ========== RECUPERAÇÃO DE SENHA ==========
    
    @GetMapping("/esqueci-senha")
    public String mostrarFormularioRecuperacao() {
        return "admin/esqueci-senha";
    }

    @PostMapping("/esqueci-senha")
    public String processarRecuperacaoSenha(@RequestParam String email, 
                                          RedirectAttributes redirectAttributes) {
        boolean emailEnviado = service.enviarEmailRecuperacao(email);
        
        if (emailEnviado) {
            redirectAttributes.addFlashAttribute("msg", 
                "Se o e-mail estiver cadastrado, você receberá uma nova senha por e-mail.");
            return "redirect:/admin/login";
        } else {
            redirectAttributes.addFlashAttribute("erro", 
                "Ocorreu um erro ao processar sua solicitação. Verifique o e-mail informado.");
            return "redirect:/admin/esqueci-senha";
        }
    }
}