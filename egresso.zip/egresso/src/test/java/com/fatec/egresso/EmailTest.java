package com.fatec.egresso;


import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@SpringBootTest
public class EmailTest {
    @Autowired
    private JavaMailSender mailSender;

    @Test
    public void testEnvioEmail() {
        try {
            System.out.println("Testando envio para: osantos.giza@gmail.com");
            
            SimpleMailMessage email = new SimpleMailMessage();
            email.setTo("deoliveira.giza@gmail.com");
            email.setSubject("TESTE SMTP - FATEC");
            email.setText("Teste " + LocalDateTime.now());
            email.setFrom("osantos.giza@gmail.com");
            
            mailSender.send(email);
            System.out.println("✅ E-mail enviado!");
        } catch (Exception e) {
            System.err.println("❌ ERRO: " + e.getMessage());
            e.printStackTrace();
        }
    }
}