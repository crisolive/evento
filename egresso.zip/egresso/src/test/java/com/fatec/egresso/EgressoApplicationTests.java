package com.fatec.egresso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EgressoApplicationTests {

	@Test
	void contextLoads() {
	}

}
