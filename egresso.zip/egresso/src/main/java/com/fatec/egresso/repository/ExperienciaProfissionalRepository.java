package com.fatec.egresso.repository;

import com.fatec.egresso.entity.ExperienciaProfissional;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExperienciaProfissionalRepository extends JpaRepository<ExperienciaProfissional, Long> {
    List<ExperienciaProfissional> findByEgressoId(Long egressoId);
}
