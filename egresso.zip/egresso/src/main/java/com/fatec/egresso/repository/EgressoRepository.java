package com.fatec.egresso.repository;

import com.fatec.egresso.entity.Egresso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface EgressoRepository extends JpaRepository<Egresso, Long> {

    // Buscar egresso por e-mail
    Optional<Egresso> findByEmail(String email);

    Optional<Egresso> findByEmailIgnoreCase(String email);

    boolean existsByEmail(String email);

    // Buscar egresso por CPF
    Optional<Egresso> findByCpf(String cpf);  // ✅ Adicionado

    boolean existsByCpf(String cpf);          // ✅ Adicionado

    List<Egresso> findByAprovadoFalse();

    List<Egresso> findByAprovadoTrue();

    Optional<Egresso> findByIdAndAprovadoTrue(Long id);

    Optional<Egresso> findByTokenConfirmacao(String token);

    @Modifying
    @Transactional
    @Query("UPDATE Egresso e SET e.emailConfirmado = :confirmado, e.tokenConfirmacao = :token WHERE e.id = :id")
    int updateEmailConfirmation(@Param("id") Long id,
                                @Param("confirmado") boolean confirmado,
                                @Param("token") String token);
}
