package com.fatec.egresso.service;

import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.exception.EmailJaCadastradoException;
import com.fatec.egresso.repository.EgressoRepository;
import com.fatec.egresso.util.CpfValidator;
import org.hibernate.Hibernate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class EgressoService {

    private final EgressoRepository repository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final JavaMailSender mailSender;

    public EgressoService(EgressoRepository repository,
                           JavaMailSender mailSender,
                           BCryptPasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.mailSender = mailSender;
        this.passwordEncoder = passwordEncoder;
    }

    public Egresso salvar(Egresso egresso) throws EmailJaCadastradoException {
        // Verificação de e-mail duplicado
        if (egresso.getEmail() != null && repository.existsByEmail(egresso.getEmail().trim())) {
            throw new EmailJaCadastradoException(
                    "Este e-mail já está cadastrado. <a href='/egresso/recuperar-senha'>Clique aqui para recuperar sua senha</a>");
        }

        // Verificação de CPF duplicado
        if (egresso.getCpf() != null && repository.findByCpf(egresso.getCpf().trim()).isPresent()) {
            throw new IllegalArgumentException("Este CPF já está cadastrado.");
        }

        // Validação do CPF
        if (!CpfValidator.isValidCPF(egresso.getCpf())) {
            throw new IllegalArgumentException("CPF inválido.");
        }

        // Validação da senha
        String senha = (egresso.getSenha() != null) ? egresso.getSenha().trim() : "";
        if (senha.length() < 8) {
            throw new IllegalArgumentException("A senha deve conter no mínimo 8 caracteres.");
        }

        // Validação do e-mail
        if (!egresso.getEmail().matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            throw new IllegalArgumentException("Por favor, insira um endereço de e-mail válido.");
        }

        // Hash da senha
        String hashSenha = passwordEncoder.encode(senha);
        egresso.setSenha(hashSenha);
        egresso.setAprovado(false);

        return repository.save(egresso);
    }

    public boolean emailJaCadastrado(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return repository.existsByEmail(email.trim());
    }

    public boolean cpfJaCadastrado(String cpf) {
        if (cpf == null || cpf.trim().isEmpty()) {
            return false;
        }
        return repository.findByCpf(cpf.trim()).isPresent();
    }

    public Egresso buscarPorId(Long id) {
        Egresso egresso = repository.findById(id).orElse(null);
        if (egresso != null) {
            Hibernate.initialize(egresso.getExperiencias());
        }
        return egresso;
    }

    public List<Egresso> listarTodos() {
        return repository.findAll();
    }

    public List<Egresso> listarNaoAprovados() {
        return repository.findByAprovadoFalse();
    }

    public List<Egresso> listarAprovados() {
        return repository.findByAprovadoTrue();
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }

    public Egresso autenticar(String email, String senhaDigitada) {
        Optional<Egresso> egressoOpt = repository.findByEmail(email.trim());

        if (egressoOpt.isPresent()) {
            Egresso egresso = egressoOpt.get();
            String senhaTratada = (senhaDigitada != null) ? senhaDigitada.trim() : "";

            if (passwordEncoder.matches(senhaTratada, egresso.getSenha())) {
                Hibernate.initialize(egresso.getExperiencias());
                return egresso;
            }
        }
        return null;
    }

    public Egresso atualizar(Egresso egresso) {
        if (!repository.existsById(egresso.getId())) {
            throw new IllegalArgumentException("Egresso não encontrado para atualização");
        }

        Egresso existente = repository.findById(egresso.getId()).orElseThrow();

        // CPF não pode ser alterado
        egresso.setCpf(existente.getCpf());

        // Email não pode ser alterado
        egresso.setEmail(existente.getEmail());

        // Mantém dados importantes
        egresso.setAprovado(existente.isAprovado());
        egresso.setEmailConfirmado(existente.isEmailConfirmado());
        egresso.setTokenConfirmacao(existente.getTokenConfirmacao());

        // Atualização da senha
        if (egresso.getSenha() != null && !egresso.getSenha().isEmpty()) {
            String novaSenha = egresso.getSenha().trim();
            if (!passwordEncoder.matches(novaSenha, existente.getSenha())) {
                if (novaSenha.length() < 8) {
                    throw new IllegalArgumentException("A nova senha deve conter no mínimo 8 caracteres.");
                }
                egresso.setSenha(passwordEncoder.encode(novaSenha));
            } else {
                egresso.setSenha(existente.getSenha());
            }
        } else {
            egresso.setSenha(existente.getSenha());
        }

        // Mantém a foto se não for alterada
        if (egresso.getFoto() == null || egresso.getFoto().isEmpty()) {
            egresso.setFoto(existente.getFoto());
        }

        return repository.save(egresso);
    }

    public boolean enviarEmailRecuperacao(String email) {
        return repository.findByEmail(email.trim())
                .map(egresso -> {
                    try {
                        String novaSenha = gerarSenhaAleatoria();
                        egresso.setSenha(passwordEncoder.encode(novaSenha.trim()));
                        repository.save(egresso);

                        SimpleMailMessage message = new SimpleMailMessage();
                        message.setTo(egresso.getEmail());
                        message.setSubject("Recuperação de Senha - Fatec Egressos");
                        message.setText(
                                "Olá, " + egresso.getNomeCompleto() + ",\n\n" +
                                        "Você solicitou uma nova senha. Aqui estão seus dados de acesso:\n\n" +
                                        "Email: " + egresso.getEmail() + "\n" +
                                        "Nova senha: " + novaSenha + "\n\n" +
                                        "Recomendamos que você altere esta senha após o login.\n\n" +
                                        "Atenciosamente,\nEquipe Fatec Egressos"
                        );
                        message.setFrom("no-reply@fatecegressos.com");
                        mailSender.send(message);

                        return true;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                })
                .orElse(false);
    }

    private String gerarSenhaAleatoria() {
        String letrasMaiusculas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String letrasMinusculas = "abcdefghijklmnopqrstuvwxyz";
        String numeros = "0123456789";
        String caracteres = letrasMaiusculas + letrasMinusculas + numeros;

        StringBuilder senha = new StringBuilder();
        Random random = new Random();

        senha.append(letrasMaiusculas.charAt(random.nextInt(letrasMaiusculas.length())));
        senha.append(letrasMinusculas.charAt(random.nextInt(letrasMinusculas.length())));
        senha.append(numeros.charAt(random.nextInt(numeros.length())));

        for (int i = 0; i < 7; i++) {
            senha.append(caracteres.charAt(random.nextInt(caracteres.length())));
        }

        char[] array = senha.toString().toCharArray();
        for (int i = 0; i < array.length; i++) {
            int randomIndex = random.nextInt(array.length);
            char temp = array[i];
            array[i] = array[randomIndex];
            array[randomIndex] = temp;
        }

        return new String(array);
    }
}
