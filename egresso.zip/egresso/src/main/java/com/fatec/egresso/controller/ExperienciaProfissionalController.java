package com.fatec.egresso.controller;

import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.entity.ExperienciaProfissional;
import com.fatec.egresso.service.ExperienciaProfissionalService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Controller
@RequestMapping("/experiencias")
public class ExperienciaProfissionalController {

    private final ExperienciaProfissionalService service;

    public ExperienciaProfissionalController(ExperienciaProfissionalService service) {
        this.service = service;
    }

    // Adiciona o egresso logado automaticamente a todos os modelos
    @ModelAttribute("egressoLogado")
    public Egresso getEgressoLogado(HttpSession session) {
        return (Egresso) session.getAttribute("egressoLogado");
    }

    @GetMapping
    public String listar(HttpSession session, Model model) {
        Egresso egresso = (Egresso) session.getAttribute("egressoLogado");
        if (egresso == null) {
            return "redirect:/login";
        }
        model.addAttribute("lista", service.listarPorEgresso(egresso.getId()));
        // Não precisa mais adicionar egressoLogado manualmente graças ao @ModelAttribute
        return "experiencia/lista";
    }

    @GetMapping("/nova/{id}")
    public String nova(@PathVariable("id") Long egressoId, Model model, HttpSession session) {
        Egresso sessaoEgresso = (Egresso) session.getAttribute("egressoLogado");
        if (sessaoEgresso == null || !sessaoEgresso.getId().equals(egressoId)) {
            return "redirect:/login";
        }

        ExperienciaProfissional experiencia = new ExperienciaProfissional();
        model.addAttribute("experiencia", experiencia);
        model.addAttribute("egressoId", egressoId);
        return "experiencia/form";
    }

    @PostMapping("/salvar")
    public String salvar(
            @ModelAttribute ExperienciaProfissional experiencia,
            @RequestParam Long egressoId,
            @RequestParam String dataInicio,
            @RequestParam(required = false) String dataFim,
            HttpSession session,
            RedirectAttributes redirectAttributes) {
        
        try {
            Egresso egresso = (Egresso) session.getAttribute("egressoLogado");
            if (egresso == null || !egresso.getId().equals(egressoId)) {
                return "redirect:/login";
            }
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            experiencia.setDataInicio(LocalDate.parse(dataInicio, formatter));
            
            if (dataFim != null && !dataFim.isEmpty()) {
                experiencia.setDataFim(LocalDate.parse(dataFim, formatter));
            } else {
                experiencia.setDataFim(null);
            }
            
            service.salvar(egressoId, experiencia);
            redirectAttributes.addFlashAttribute("success", "Experiência salva com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao salvar: " + e.getMessage());
            return "redirect:/experiencias/nova/" + egressoId;
        }
        
        return "redirect:/experiencias";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        Egresso egresso = (Egresso) session.getAttribute("egressoLogado");
        if (egresso == null) {
            return "redirect:/login";
        }

        ExperienciaProfissional experiencia = service.buscarPorId(id);
        if (experiencia == null || !experiencia.getEgresso().getId().equals(egresso.getId())) {
            return "redirect:/experiencias";
        }

        model.addAttribute("experiencia", experiencia);
        model.addAttribute("egressoId", egresso.getId());
        return "experiencia/form";
    }

    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        Egresso egresso = (Egresso) session.getAttribute("egressoLogado");
        if (egresso == null) {
            return "redirect:/login";
        }

        ExperienciaProfissional experiencia = service.buscarPorId(id);
        if (experiencia == null || !experiencia.getEgresso().getId().equals(egresso.getId())) {
            redirectAttributes.addFlashAttribute("error", "Experiência não encontrada ou não pertence a você.");
            return "redirect:/egresso/perfil";
        }

        service.excluir(id);
        redirectAttributes.addFlashAttribute("success", "Experiência excluída com sucesso!");

        return "redirect:/egresso/perfil";
    }

}