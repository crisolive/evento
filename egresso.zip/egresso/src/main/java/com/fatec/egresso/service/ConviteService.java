package com.fatec.egresso.service;

import com.fatec.egresso.entity.Convite;
import com.fatec.egresso.repository.ConviteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ConviteService {

    private final ConviteRepository repository;
    private final EmailService emailService;

    // Injeção de dependência dos serviços necessários
    public ConviteService(ConviteRepository repository, EmailService emailService) {
        this.repository = repository;
        this.emailService = emailService;
    }

    public List<Convite> listarTodos() {
        return repository.findAll();
    }

    @Transactional
    public Convite salvar(Convite convite) {
        // Define a data de envio como agora
        convite.setDataEnvio(LocalDateTime.now());
        
        // Salva o convite no banco de dados
        Convite conviteSalvo = repository.save(convite);
        
        // Envia os e-mails para todos os destinatários
        enviarEmailsParaDestinatarios(conviteSalvo);
        
        return conviteSalvo;
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }

    /**
     * Método para enviar e-mails para todos os destinatários listados
     * @param convite O convite contendo os dados do egresso e a mensagem
     */
    private void enviarEmailsParaDestinatarios(Convite convite) {
        // Verifica se há e-mails para enviar
        if (convite.getEmailEgresso() == null || convite.getEmailEgresso().trim().isEmpty()) {
            return;
        }
        
        // Divide a string de e-mails usando o ponto e vírgula como separador
        String[] emails = convite.getEmailEgresso().split(";");
        
        // Para cada e-mail encontrado
        for (String email : emails) {
            String emailLimpo = email.trim();
            
            // Verifica se o e-mail não está vazio
            if (!emailLimpo.isEmpty()) {
                // Envia o e-mail individualmente
                enviarEmailIndividual(convite, emailLimpo);
            }
        }
    }

    /**
     * Envia um e-mail para um destinatário específico
     * @param convite Dados do convite
     * @param destinatario E-mail do destinatário
     */
    private void enviarEmailIndividual(Convite convite, String destinatario) {
        try {
            String assunto = "🎓 Convite FATEC Zona Leste - Sistema de Egressos";
            
            // Corpo do e-mail formatado
            String mensagem = String.format(
                "Prezado Egresso,\n\n" +
                "%s\n\n" +
                "Atenciosamente,\n" +
                "Equipe FATEC Zona Leste\n\n" +
                "Data do envio: %s",
                convite.getMensagem(),
                convite.getDataEnvio().toString()
            );
            
            // Envia o e-mail usando o serviço de e-mail
            emailService.enviarEmail(
                destinatario,
                assunto,
                mensagem
            );
            
        } catch (Exception e) {
            // Loga o erro no console (pode ser substituído por um logger)
            System.err.println("Erro ao enviar e-mail para: " + destinatario);
            e.printStackTrace();
        }
    }
}