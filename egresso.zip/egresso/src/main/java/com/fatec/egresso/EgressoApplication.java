
package com.fatec.egresso;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.fatec.egresso.entity.Administrador;
import com.fatec.egresso.service.AdministradorService;

@SpringBootApplication
public class EgressoApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(EgressoApplication.class, args);
	}

	@Bean
	public ApplicationRunner inserirAdmin(AdministradorService administradorService) {
	    return args -> {
	        if (administradorService.verificarRepositorioVazio() ) {
	            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	            Administrador admin = Administrador.builder()  // Se usar Builder pattern
	                .nome("Administrador")
	                .email("adm@gmail.com")
	                .senha(passwordEncoder.encode("adm123".trim()))
	                .role("ADMIN")
	                .build();
	            
	            administradorService.salvar(admin);
	            
	            System.out.println("=".repeat(50));
	            System.out.println("✅ ADMIN CRIADO COM SUCESSO!");
	            System.out.println("📧 Email: adm@gmail.com");
	            System.out.println("🔑 Senha: adm123");
	            System.out.println("=".repeat(50));
	        }
	    };
	}
}


