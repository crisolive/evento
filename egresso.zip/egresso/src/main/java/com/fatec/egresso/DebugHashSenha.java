package com.fatec.egresso;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class DebugHashSenha {
    public static void main(String[] args) {
        // 1. Instancie o codificador
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        
        // 2. Defina a senha de teste
        String senhaTeste = "adm123";
        
        // 3. Gere um NOVO hash a partir da senha
        String novoHash = encoder.encode(senhaTeste);
        
        // 4. Imprima resultados
        System.out.println("======================================");
        System.out.println("Senha testada: \t\t" + senhaTeste);
        System.out.println("Novo hash gerado: \t" + novoHash);
        System.out.println("Tamanho do hash: \t" + novoHash.length() + " caracteres");
        System.out.println("======================================");
        
        // 5. Verifique se o novo hash funciona
        boolean isValid = encoder.matches(senhaTeste, novoHash);
        System.out.println("Validação com novo hash: " + isValid);
    }
}