package com.fatec.egresso.controller;

import com.fatec.egresso.entity.Convite;
import com.fatec.egresso.service.ConviteService;
import java.time.LocalDateTime;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/convites")
public class ConviteController {

    private final ConviteService service;

    // Injeção de dependência do serviço
    public ConviteController(ConviteService service) {
        this.service = service;
    }

    // Lista todos os convites
    @GetMapping("/lista")
    public String listar(Model model) {
        model.addAttribute("convites", service.listarTodos());
        return "convites/lista";
    }

    // Exibe o formulário para novo convite
    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("convite", new Convite());
        return "convites/novo";
    }
    
    // Processa o envio do formulário
    @PostMapping("/novo")
    public String salvar(@ModelAttribute Convite convite) {
        // Define a data atual como data de envio
        convite.setDataEnvio(LocalDateTime.now());
        
        // Chama o serviço para salvar e enviar os emails
        service.salvar(convite);
        
        // Redireciona para a lista de convites
        return "redirect:/convites/lista";
    }

    // Exclui um convite pelo ID
    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        service.excluir(id);
        return "redirect:/convites/lista";
    }
}