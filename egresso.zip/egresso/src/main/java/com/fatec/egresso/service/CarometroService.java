package com.fatec.egresso.service;

import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.repository.EgressoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarometroService {

    private final EgressoRepository egressoRepository;

    public CarometroService(EgressoRepository egressoRepository) {
        this.egressoRepository = egressoRepository;
    }

    /**
     * Lista todos os egressos aprovados (para exibição no carômetro público).
     */
    public List<Egresso> listarEgressosAprovados() {
        return egressoRepository.findByAprovadoTrue();
    }

    /**
     * Busca um egresso aprovado por ID.
     * 
     * @param id ID do egresso
     * @return Egresso, se aprovado e existente
     * @throws RuntimeException caso não encontre ou não esteja aprovado
     */
    public Egresso buscarEgressoAprovadoPorId(Long id) {
        return egressoRepository.findByIdAndAprovadoTrue(id)
                .orElseThrow(() -> new RuntimeException("Egresso não encontrado ou não aprovado com o ID: " + id));
    }
}
