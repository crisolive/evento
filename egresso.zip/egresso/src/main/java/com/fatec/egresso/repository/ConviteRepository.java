package com.fatec.egresso.repository;

import com.fatec.egresso.entity.Convite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConviteRepository extends JpaRepository<Convite, Long> {
}
