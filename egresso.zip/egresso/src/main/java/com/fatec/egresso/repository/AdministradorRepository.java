package com.fatec.egresso.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fatec.egresso.entity.Administrador;

public interface AdministradorRepository extends JpaRepository<Administrador, Long> {
    
    
    Optional<Administrador> findByEmail(String email);
}