package com.fatec.egresso.service;

import com.fatec.egresso.entity.Administrador;
import com.fatec.egresso.repository.AdministradorRepository;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class AdministradorService {
    private final AdministradorRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final JavaMailSender mailSender;

    public AdministradorService(AdministradorRepository repository, 
                              PasswordEncoder passwordEncoder,
                              JavaMailSender mailSender) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
        this.mailSender = mailSender;
    }

    // Listar todos os administradores
    public List<Administrador> listarTodos() {
        return repository.findAll();
    }

    // Buscar administrador por ID
    public Administrador buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }

    // Excluir administrador por ID
    public void excluir(Long id) {
        // Verifica se existe antes de excluir
        if (repository.existsById(id)) {
            repository.deleteById(id);
        }
    }
    
    public boolean verificarRepositorioVazio() {
    	return (repository.count()==0? true :false);
    }

    // Salvar ou atualizar administrador com validações
    public void salvar(Administrador admin) {
        // Validações básicas
        if (admin.getEmail() == null || admin.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("O e-mail é obrigatório.");
        }

        if (admin.getSenha() == null || admin.getSenha().trim().length() < 8) {
            throw new IllegalArgumentException("A senha deve ter no mínimo 8 caracteres.");
        }

        // Verifica se é um novo registro (ID nulo) ou uma atualização
        if (admin.getId() == null) {
            // Validação para novo administrador
            validarNovoAdministrador(admin);
        } else {
            // Validação para atualização de administrador
            validarAtualizacaoAdministrador(admin);
        }

        // Criptografa a senha antes de salvar
       // String senhaCriptografada = passwordEncoder.encode(admin.getSenha().trim());
        admin.setSenha(passwordEncoder.encode(admin.getSenha().trim()));
        
        repository.save(admin);
    }
    
    // Buscar administrador por e-mail
    public Administrador buscarPorEmail(String email) {
        return repository.findByEmail(email).orElse(null);
    }

    // Buscar administrador por e-mail e verificar senha
    public Administrador buscarPorEmailESenha(String email, String senha) {
        Optional<Administrador> optionalAdmin = repository.findByEmail(email);
        if (optionalAdmin.isPresent()) {
            Administrador admin = optionalAdmin.get();
            // DEBUG: Mostra o que está sendo comparado
            System.out.println("🔍 Email digitado: '" + email + "'");
            System.out.println("🔍 Email no banco: '" + admin.getEmail()+ "'");
            System.out.println("🔍 Senha digitada: '" + senha+ "'");
            System.out.println("📏 Tamanho do hash: " + admin.getSenha().length());
            System.out.println("🔍 Senha no banco (hash): " + admin.getSenha());
            if (passwordEncoder.matches(senha, admin.getSenha().trim() )) {
            	System.out.println("A senha funcionou");
                return admin;
            }
        }
        return null;
    }

    // Métodos auxiliares para validação
    private void validarNovoAdministrador(Administrador admin) {
        Optional<Administrador> adminExistente = repository.findByEmail(admin.getEmail().trim());
        if (adminExistente.isPresent()) {
            throw new IllegalArgumentException("O e-mail " + admin.getEmail() + " já está cadastrado.");
        }
    }

    private void validarAtualizacaoAdministrador(Administrador admin) {
        Optional<Administrador> adminExistente = repository.findByEmail(admin.getEmail().trim());
        
        // Verifica se o e-mail está sendo alterado para um que já existe (e pertence a outro admin)
        if (adminExistente.isPresent() && !adminExistente.get().getId().equals(admin.getId())) {
            throw new IllegalArgumentException("Este e-mail já está cadastrado para outro administrador.");
        }
    }

    // ========== MÉTODOS PARA RECUPERAÇÃO DE SENHA ==========
    
    public boolean enviarEmailRecuperacao(String email) {
        Optional<Administrador> optionalAdmin = repository.findByEmail(email.trim());
        
        if (optionalAdmin.isEmpty()) {
            return false;
        }
        
        Administrador admin = optionalAdmin.get();
        
        try {
            // 1. Gerar nova senha aleatória
            String novaSenha = gerarSenhaAleatoria();
            
            // 2. Atualizar a senha no banco (criptografada)
            admin.setSenha(passwordEncoder.encode(novaSenha));
            repository.save(admin);
            
            // 3. Enviar email com a nova senha
            enviarEmailComNovaSenha(admin.getEmail(), novaSenha);
            
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private String gerarSenhaAleatoria() {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder senha = new StringBuilder();
        Random random = new Random();
        
        // Garante que a senha tenha 10 caracteres
        for (int i = 0; i < 10; i++) {
            senha.append(caracteres.charAt(random.nextInt(caracteres.length())));
        }
        
        return senha.toString();
    }
    
    private void enviarEmailComNovaSenha(String emailDestino, String novaSenha) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(emailDestino);
        message.setSubject("Recuperação de Senha - Administrador");
        message.setText(
            "Olá, administrador,\n\n" +
            "Sua nova senha temporária é: " + novaSenha + "\n\n" +
            "Por segurança, recomendamos que você altere esta senha após o login.\n\n" +
            "Atenciosamente,\nEquipe Fatec Egressos"
        );
        message.setFrom("no-reply@fatecegressos.com");
        
        mailSender.send(message);
    }
    
    // ========== MÉTODOS PARA ENVIO DE E-MAIL DE REJEIÇÃO ==========
    
    public boolean enviarEmailRejeicao(String emailDestino, String nomeEgresso, String motivoPrincipal, String[] motivosAdicionais) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(emailDestino);
            message.setSubject("Cadastro Rejeitado - Sistema de Egressos FATEC");
            
            // Construir mensagem personalizada
            String textoEmail = construirMensagemRejeicao(nomeEgresso, motivoPrincipal, motivosAdicionais);
            message.setText(textoEmail);
            
            message.setFrom("no-reply@fatecegressos.com");
            
            mailSender.send(message);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private String construirMensagemRejeicao(String nomeEgresso, String motivoPrincipal, String[] motivosAdicionais) {
        StringBuilder mensagem = new StringBuilder();
        
        mensagem.append("Prezado(a) ").append(nomeEgresso != null ? nomeEgresso : "").append(",\n\n");
        mensagem.append("Lamentamos informar que seu cadastro no Sistema de Egressos da FATEC foi rejeitado após análise.\n\n");
        
        mensagem.append("Motivo principal da rejeição:\n");
        mensagem.append("• ").append(motivoPrincipal).append("\n\n");
        
        if (motivosAdicionais != null && motivosAdicionais.length > 0) {
            mensagem.append("Outros motivos que podem levar à rejeição do cadastro:\n");
            for (String motivo : motivosAdicionais) {
                mensagem.append("• ").append(motivo).append("\n");
            }
            mensagem.append("\n");
        }
        
        mensagem.append("O que você pode fazer:\n");
        mensagem.append("1. Caso acredite que houve um equívoco, realize um novo cadastro, certifique-se de atender a todos os requisitos.\n\n");
        mensagem.append("2. Por favor não responda este e-mail.\n\n");
        
        mensagem.append("Agradecemos seu interesse em fazer parte de nossa rede de egressos.\n\n");
        mensagem.append("Atenciosamente,\n");
        mensagem.append("Coordenação\n");
        mensagem.append("FATEC - Faculdade de Tecnologia\n");
        mensagem.append("Sistema de Egressos\n");
        
        return mensagem.toString();
    }
}