package com.fatec.egresso.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    /**
     * Envia e-mail com texto simples
     */
    public void enviarEmail(String destinatario, String assunto, String mensagem) {
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(destinatario);
        email.setSubject(assunto);
        email.setText(mensagem);
        email.setFrom("osantos.giza@gmail.com");

        mailSender.send(email);
    }

    /**
     * Envia e-mail com conteúdo HTML
     * @param destinatario Email do destinatário
     * @param assunto Assunto do e-mail
     * @param conteudoHtml Conteúdo em HTML
     * @throws MessagingException Se ocorrer erro ao montar a mensagem
     */
    public void enviarEmailHtml(String destinatario, String assunto, String conteudoHtml) throws MessagingException {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        
        helper.setTo(destinatario);
        helper.setSubject(assunto);
        helper.setText(conteudoHtml, true); // true indica que é HTML
        helper.setFrom("osantos.giza@gmail.com");

        mailSender.send(mimeMessage);
    }

    /**
     * Versão sobrecarregada que aceita cópia (CC)
     */
    public void enviarEmailHtml(String destinatario, String cc, String assunto, String conteudoHtml) 
            throws MessagingException {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
        
        helper.setTo(destinatario);
        if (cc != null && !cc.isEmpty()) {
            helper.setCc(cc);
        }
        helper.setSubject(assunto);
        helper.setText(conteudoHtml, true);
        helper.setFrom("osantos.giza@gmail.com");

        mailSender.send(mimeMessage);
    }

    /**
     * Envia e-mail de confirmação com link contendo o token
     * @param destinatario Email do egresso
     * @param token Código único para confirmação
     */
    public void enviarEmailConfirmacao(String destinatario, String token) {
        String link = "http://localhost:8081/egresso/confirmar?token=" + token;

        String assunto = "Confirmação de E-mail - Sistema de Egressos";
        String conteudoHtml = """
                <p>Olá!</p>
                <p>Obrigado pelo seu cadastro no Sistema de Egressos da Fatec.</p>
                <p>Para confirmar seu e-mail, clique no link abaixo:</p>
                <p><a href="%s">Confirmar e-mail</a></p>
                <br>
                <p>Se você não fez esse cadastro, ignore este e-mail.</p>
                """.formatted(link);

        try {
            enviarEmailHtml(destinatario, assunto, conteudoHtml);
        } catch (MessagingException e) {
            e.printStackTrace(); // aqui você pode adicionar um log ou tratamento melhor
        }
    }
}
