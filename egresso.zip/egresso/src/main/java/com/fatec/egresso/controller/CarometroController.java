package com.fatec.egresso.controller;

import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.entity.ExperienciaProfissional;
import com.fatec.egresso.service.CarometroService;
import com.fatec.egresso.service.ExperienciaProfissionalService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class CarometroController {

    private final CarometroService carometroService;
    private final ExperienciaProfissionalService experienciaProfissionalService;

    public CarometroController(CarometroService carometroService,
                               ExperienciaProfissionalService experienciaProfissionalService) {
        this.carometroService = carometroService;
        this.experienciaProfissionalService = experienciaProfissionalService;
    }

    @GetMapping("/carometro")
    public String exibirCarometro(Model model) {
        List<Egresso> egressos = carometroService.listarEgressosAprovados();
        model.addAttribute("egressos", egressos);
        return "carometro/home";
    }

    @GetMapping("/carometro/home")
    public String exibirHome(Model model) {
        List<Egresso> egressos = carometroService.listarEgressosAprovados();
        model.addAttribute("egressos", egressos);
        return "carometro/home";
    }
    
    @GetMapping("/carometro/perfil_publico/{id}")
    public String mostrarPerfilPublico(@PathVariable Long id, Model model) {
        // Busca o egresso aprovado
        Egresso egresso = carometroService.buscarEgressoAprovadoPorId(id);
        
        // Se não encontrou, redireciona para a home do carômetro
        if (egresso == null) {
            return "redirect:/carometro/home";
        }
        
        // Busca as experiências profissionais deste egresso
        List<ExperienciaProfissional> experiencias = experienciaProfissionalService.listarPorEgresso(id);
        
        // Adiciona os atributos ao modelo
        model.addAttribute("egresso", egresso);
        model.addAttribute("experiencias", experiencias);
        
        return "carometro/perfil_publico";
    }
}