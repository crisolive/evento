package com.fatec.egresso.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.Period;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExperienciaProfissional {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cargo;
    private String empresa;
    
    @Column(name = "data_inicio")
    private LocalDate dataInicio;
    
    @Column(name = "data_fim")
    private LocalDate dataFim;
    
    @Transient  // Este campo não será persistido no banco
    private String tempoTrabalho;
    
    private String oQueFaz;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "egresso_id", nullable = false)
    private Egresso egresso;

    // Método para calcular o tempo de trabalho
    public String calcularTempoTrabalho() {
        if (dataInicio == null) {
            return "Data de início não informada";
        }
        
        LocalDate dataFinal = (dataFim != null) ? dataFim : LocalDate.now();
        
        Period periodo = Period.between(dataInicio, dataFinal);
        
        int anos = periodo.getYears();
        int meses = periodo.getMonths();
        
        if (anos > 0 && meses > 0) {
            return anos + " ano(s) e " + meses + " mes(es)";
        } else if (anos > 0) {
            return anos + " ano(s)";
        } else if (meses > 0) {
            return meses + " mes(es)";
        } else {
            return "Menos de 1 mês";
        }
    }

    // Método para evitar recursão infinita no JSON
    @Override
    public String toString() {
        return "ExperienciaProfissional{" +
                "id=" + id +
                ", cargo='" + cargo + '\'' +
                ", empresa='" + empresa + '\'' +
                ", dataInicio='" + dataInicio + '\'' +
                ", dataFim='" + dataFim + '\'' +
                ", tempoTrabalho='" + calcularTempoTrabalho() + '\'' +
                ", oQueFaz='" + oQueFaz + '\'' +
                '}';
    }
}