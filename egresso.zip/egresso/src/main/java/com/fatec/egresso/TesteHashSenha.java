package com.fatec.egresso; // Altere conforme seu pacote

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class TesteHashSenha {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String senha = "12345678"; // senha digitada
        String hash = "$2a$10$4sHLiCUVpBq7UDVZnDmis.ZS0P3ctuX6MneqliDamIea4g9ODFRKS"; // hash já salvo

        boolean resultado = encoder.matches(senha, hash);
        System.out.println("Senha correta? " + resultado); // Deve imprimir true
    }
}
