package com.fatec.egresso.controller;

import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.entity.ExperienciaProfissional;
import com.fatec.egresso.exception.EmailJaCadastradoException;
import com.fatec.egresso.repository.EgressoRepository;
import com.fatec.egresso.service.EgressoService;
import com.fatec.egresso.service.EmailService;
import com.fatec.egresso.service.ExperienciaProfissionalService;
import com.fatec.egresso.util.CpfValidator;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Controller
@RequestMapping("/egresso")
public class EgressoController {

    private final EgressoService service;
    private final ExperienciaProfissionalService experienciaProfissionalService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private EmailService emailService;

    @Autowired
    private EgressoRepository egressoRepository;

    @Value("${app.upload.dir}")
    private String uploadDir;

    public EgressoController(EgressoService service,
                              ExperienciaProfissionalService experienciaProfissionalService) {
        this.service = service;
        this.experienciaProfissionalService = experienciaProfissionalService;
    }

    @GetMapping("/login")
    public String loginForm() {
        return "egresso/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                         @RequestParam String senha,
                         HttpSession session,
                         Model model) {
        Optional<Egresso> egressoOpt = egressoRepository.findByEmail(email);

        if (egressoOpt.isEmpty()) {
            model.addAttribute("erro", "E-mail não cadastrado");
            return "egresso/login";
        }

        Egresso egresso = egressoOpt.get();

        if (!egresso.isEmailConfirmado()) {
            model.addAttribute("erro", "Por favor, confirme seu e-mail antes de fazer login.");
            return "egresso/login";
        }

        if (!passwordEncoder.matches(senha, egresso.getSenha())) {
            model.addAttribute("erro", "Senha incorreta");
            return "egresso/login";
        }

        session.setAttribute("egressoLogado", egresso);
        return "redirect:/egresso/perfil";
    }

    @GetMapping("/termos-de-uso")
    public String termosDeUso() {
        return "egresso/termos-de-uso";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/egresso/login";
    }

    @GetMapping("/cadastro")
    public String cadastroForm(Model model) {
        model.addAttribute("egresso", new Egresso());
        return "egresso/cadastro";
    }

    @PostMapping("/cadastro")
    public String cadastrar(
            @RequestParam String nomeCompleto,
            @RequestParam int idade,
            @RequestParam String curso,
            @RequestParam int anoConclusao,
            @RequestParam(required = false) String linkedin,
            @RequestParam(required = false) String github,
            @RequestParam(required = false) String letters,
            @RequestParam String cpf,
            @RequestParam String email,
            @RequestParam String senha,
            @RequestParam(required = false) String comentarioFatec,
            @RequestParam(required = false) String comentarioLivre,
            @RequestParam boolean concordaTermos,
            @RequestParam(required = false, defaultValue = "false") boolean dadosPublicos,
            @RequestParam("foto") MultipartFile arquivoFoto,
            RedirectAttributes redirectAttributes,
            HttpSession session) {

        if (!concordaTermos) {
            redirectAttributes.addFlashAttribute("erro", "Você precisa concordar com os termos de uso para se cadastrar.");
            return "redirect:/egresso/cadastro";
        }

        try {
            if (service.emailJaCadastrado(email)) {
                redirectAttributes.addFlashAttribute("erro", "Este e-mail já está cadastrado. <a href=\"/egresso/recuperar-senha\">Clique aqui para recuperar sua senha</a>");
                preencherCampos(redirectAttributes, nomeCompleto, idade, curso, anoConclusao, linkedin, github, letters, cpf, email, comentarioFatec, comentarioLivre, dadosPublicos);
                return "redirect:/egresso/cadastro";
            }

            if (service.cpfJaCadastrado(cpf)) {
                redirectAttributes.addFlashAttribute("erro", "Este CPF já está cadastrado.");
                preencherCampos(redirectAttributes, nomeCompleto, idade, curso, anoConclusao, linkedin, github, letters, cpf, email, comentarioFatec, comentarioLivre, dadosPublicos);
                return "redirect:/egresso/cadastro";
            }

            if (!CpfValidator.isValidCPF(cpf)) {
                redirectAttributes.addFlashAttribute("erro", "CPF inválido.");
                preencherCampos(redirectAttributes, nomeCompleto, idade, curso, anoConclusao, linkedin, github, letters, cpf, email, comentarioFatec, comentarioLivre, dadosPublicos);
                return "redirect:/egresso/cadastro";
            }

            Egresso egresso = new Egresso();
            egresso.setNomeCompleto(nomeCompleto);
            egresso.setIdade(idade);
            egresso.setCurso(curso);
            egresso.setAnoConclusao(anoConclusao);
            egresso.setLinkedin(linkedin);
            egresso.setGithub(github);
            egresso.setLetters(letters);
            egresso.setCpf(cpf);
            egresso.setEmail(email);
            egresso.setSenha(senha);
            egresso.setComentarioFatec(comentarioFatec);
            egresso.setComentarioLivre(comentarioLivre);
            egresso.setConcordaTermos(concordaTermos);
            egresso.setDadosPublicos(dadosPublicos);
            egresso.setAprovado(false);

            String token = UUID.randomUUID().toString();
            egresso.setTokenConfirmacao(token);
            egresso.setEmailConfirmado(false);

            if (!arquivoFoto.isEmpty()) {
                String nomeArquivo = salvarFotoNoDisco(arquivoFoto);
                egresso.setFoto(nomeArquivo);
            }

            Egresso egressoSalvo = service.salvar(egresso);
            emailService.enviarEmailConfirmacao(egresso.getEmail(), token);

            session.setAttribute("egressoLogado", egressoSalvo);
            return "redirect:/egresso/cadastro-sucesso";

        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("erro", "Erro ao salvar a foto: " + e.getMessage());
            return "redirect:/egresso/cadastro";
        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("erro", "Erro ao enviar e-mail de confirmação: " + e.getMessage());
            return "redirect:/egresso/cadastro";
        }
    }

    @GetMapping("/confirmar")
    public String confirmarEmail(@RequestParam("token") String token, Model model) {
        try {
            Egresso egresso = egressoRepository.findByTokenConfirmacao(token)
                    .orElseThrow(() -> new RuntimeException("Token inválido ou expirado."));

            egresso.setEmailConfirmado(true);
            egresso.setTokenConfirmacao(null);
            egressoRepository.save(egresso);
            model.addAttribute("mensagem", "E-mail confirmado com sucesso!");
        } catch (RuntimeException e) {
            model.addAttribute("mensagem", e.getMessage());
        }
        return "egresso/confirmacao";
    }

    @GetMapping("/cadastro-sucesso")
    public String cadastroSucesso() {
        return "egresso/cadastro-sucesso";
    }

    @GetMapping("/perfil")
    public String perfil(HttpSession session, Model model) {
        Egresso egresso = (Egresso) session.getAttribute("egressoLogado");
        if (egresso == null) return "redirect:/egresso/login";

        List<ExperienciaProfissional> experiencias = experienciaProfissionalService.listarPorEgresso(egresso.getId());
        model.addAttribute("experiencias", experiencias);
        model.addAttribute("egresso", egresso);
        return "egresso/perfil";
    }

    @GetMapping("/editar")
    public String editarForm(HttpSession session, Model model) {
        Egresso egresso = (Egresso) session.getAttribute("egressoLogado");
        if (egresso == null) return "redirect:/egresso/login";
        model.addAttribute("egresso", egresso);
        return "egresso/editar";
    }

    @PostMapping("/editar")
    public String editarPerfil(
            @RequestParam String nomeCompleto,
            @RequestParam int idade,
            @RequestParam String curso,
            @RequestParam int anoConclusao,
            @RequestParam(required = false) String linkedin,
            @RequestParam(required = false) String github,
            @RequestParam(required = false) String letters,
            @RequestParam String email,
            @RequestParam(required = false) String senhaAtual,
            @RequestParam(required = false) String novaSenha,
            @RequestParam(required = false) String comentarioFatec,
            @RequestParam(required = false) String comentarioLivre,
            @RequestParam(required = false, defaultValue = "false") boolean dadosPublicos,
            @RequestParam(value = "foto", required = false) MultipartFile arquivoFoto,
            RedirectAttributes redirectAttributes,
            HttpSession session) {

        try {
            Egresso egressoLogado = (Egresso) session.getAttribute("egressoLogado");
            if (egressoLogado == null) {
                return "redirect:/egresso/login";
            }

            Egresso egresso = service.buscarPorId(egressoLogado.getId());

            egresso.setNomeCompleto(nomeCompleto);
            egresso.setIdade(idade);
            egresso.setCurso(curso);
            egresso.setAnoConclusao(anoConclusao);
            egresso.setLinkedin(linkedin);
            egresso.setGithub(github);
            egresso.setLetters(letters);
            egresso.setEmail(email);
            egresso.setComentarioFatec(comentarioFatec);
            egresso.setComentarioLivre(comentarioLivre);
            egresso.setDadosPublicos(dadosPublicos);

            if (novaSenha != null && !novaSenha.isEmpty()) {
                if (senhaAtual == null || senhaAtual.isEmpty()) {
                    redirectAttributes.addFlashAttribute("erro", "Para alterar a senha, informe a senha atual.");
                    return "redirect:/egresso/editar";
                }

                if (!passwordEncoder.matches(senhaAtual, egresso.getSenha())) {
                    redirectAttributes.addFlashAttribute("erro", "Senha atual incorreta.");
                    return "redirect:/egresso/editar";
                }

                if (novaSenha.length() < 8) {
                    redirectAttributes.addFlashAttribute("erro", "A nova senha deve ter no mínimo 8 caracteres.");
                    return "redirect:/egresso/editar";
                }

                egresso.setSenha(novaSenha);
            }

            if (arquivoFoto != null && !arquivoFoto.isEmpty()) {
                String nomeArquivo = salvarFotoNoDisco(arquivoFoto);
                egresso.setFoto(nomeArquivo);
            }

            Egresso egressoAtualizado = service.atualizar(egresso);
            session.setAttribute("egressoLogado", egressoAtualizado);

            redirectAttributes.addFlashAttribute("sucesso", "Perfil atualizado com sucesso!");
            return "redirect:/egresso/perfil";

        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("erro", "Erro ao atualizar perfil: " + e.getMessage());
            return "redirect:/egresso/editar";
        }
    }

    @GetMapping("/fotos/{nomeArquivo}")
    public ResponseEntity<byte[]> exibirFoto(@PathVariable String nomeArquivo) throws IOException {
        Path caminhoFoto = Paths.get(uploadDir + nomeArquivo);

        if (!Files.exists(caminhoFoto)) {
            return ResponseEntity.notFound().build();
        }

        byte[] fotoBytes = Files.readAllBytes(caminhoFoto);
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(fotoBytes);
    }

    private String salvarFotoNoDisco(MultipartFile arquivoFoto) throws IOException {
        if (arquivoFoto.isEmpty()) {
            throw new IOException("Arquivo vazio");
        }

        String contentType = arquivoFoto.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            throw new IOException("Tipo de arquivo inválido. Apenas imagens são permitidas.");
        }

        Path uploadPath = Paths.get(uploadDir);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        String nomeArquivo = UUID.randomUUID() + "_" + StringUtils.cleanPath(arquivoFoto.getOriginalFilename());
        Path caminhoCompleto = uploadPath.resolve(nomeArquivo);

        try (var inputStream = arquivoFoto.getInputStream()) {
            Files.copy(inputStream, caminhoCompleto, StandardCopyOption.REPLACE_EXISTING);
        }

        return nomeArquivo;
    }

    @GetMapping("/perfil/{id}")
    public String visualizarPerfil(@PathVariable Long id, Model model) {
        Egresso egresso = service.buscarPorId(id);
        if (egresso == null || !egresso.isDadosPublicos() || !egresso.isAprovado()) {
            return "redirect:/carometro";
        }

        List<ExperienciaProfissional> experiencias = experienciaProfissionalService.listarPorEgresso(id);
        model.addAttribute("egresso", egresso);
        model.addAttribute("experiencias", experiencias);
        return "egresso/perfil_publico";
    }

    @GetMapping("/esqueci_senha")
    public String mostrarFormularioRecuperacao() {
        return "egresso/esqueci_senha";
    }

    @PostMapping("/esqueci_senha")
    public String processarRecuperacaoSenha(@RequestParam String email,
                                             RedirectAttributes redirectAttributes) {
        boolean emailEnviado = service.enviarEmailRecuperacao(email);

        if (emailEnviado) {
            redirectAttributes.addFlashAttribute("msg",
                    "Se o e-mail estiver cadastrado, você receberá uma nova senha.");
        } else {
            redirectAttributes.addFlashAttribute("erro",
                    "Ocorreu um erro ao processar sua solicitação.");
        }

        return "redirect:/egresso/esqueci_senha";
    }

    //  Método preencher Campos
    private void preencherCampos(
            RedirectAttributes redirectAttributes,
            String nomeCompleto,
            int idade,
            String curso,
            int anoConclusao,
            String linkedin,
            String github,
            String letters,
            String cpf,
            String email,
            String comentarioFatec,
            String comentarioLivre,
            boolean dadosPublicos
    ) {
        redirectAttributes.addFlashAttribute("nomeCompleto", nomeCompleto);
        redirectAttributes.addFlashAttribute("idade", idade);
        redirectAttributes.addFlashAttribute("curso", curso);
        redirectAttributes.addFlashAttribute("anoConclusao", anoConclusao);
        redirectAttributes.addFlashAttribute("linkedin", linkedin);
        redirectAttributes.addFlashAttribute("github", github);
        redirectAttributes.addFlashAttribute("letters", letters);
        redirectAttributes.addFlashAttribute("cpf", cpf);
        redirectAttributes.addFlashAttribute("email", email);
        redirectAttributes.addFlashAttribute("comentarioFatec", comentarioFatec);
        redirectAttributes.addFlashAttribute("comentarioLivre", comentarioLivre);
        redirectAttributes.addFlashAttribute("dadosPublicos", dadosPublicos);
    }
}
