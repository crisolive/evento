package com.fatec.egresso.service;

import com.fatec.egresso.entity.Egresso;
import com.fatec.egresso.entity.ExperienciaProfissional;
import com.fatec.egresso.repository.EgressoRepository;
import com.fatec.egresso.repository.ExperienciaProfissionalRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ExperienciaProfissionalService {

    private final ExperienciaProfissionalRepository experienciaRepository;
    private final EgressoRepository egressoRepository;

    public ExperienciaProfissionalService(ExperienciaProfissionalRepository experienciaRepository,
                                        EgressoRepository egressoRepository) {
        this.experienciaRepository = experienciaRepository;
        this.egressoRepository = egressoRepository;
    }

    public List<ExperienciaProfissional> listarPorEgresso(Long egressoId) {
        if (egressoId == null) {
            throw new IllegalArgumentException("ID do egresso não pode ser nulo");
        }
        return experienciaRepository.findByEgressoId(egressoId);
    }

    @Transactional
    public ExperienciaProfissional salvar(Long egressoId, ExperienciaProfissional experiencia) {
        if (egressoId == null) {
            throw new IllegalArgumentException("ID do egresso não pode ser nulo");
        }
        if (experiencia == null) {
            throw new IllegalArgumentException("Experiência não pode ser nula");
        }

        Egresso egresso = egressoRepository.findById(egressoId)
                .orElseThrow(() -> new RuntimeException("Egresso não encontrado com ID: " + egressoId));
        
        // Validação das datas
        validarDatasExperiencia(experiencia);
        
        // Garante que a experiência está associada ao egresso correto
        experiencia.setEgresso(egresso);
        
        // Validação adicional dos campos obrigatórios
        validarCamposObrigatorios(experiencia);

        // Calcula e atualiza o tempo de trabalho
        experiencia.setTempoTrabalho(experiencia.calcularTempoTrabalho());

        return experienciaRepository.save(experiencia);
    }

    public ExperienciaProfissional buscarPorId(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("ID não pode ser nulo");
        }
        return experienciaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Experiência não encontrada com ID: " + id));
    }

    @Transactional
    public void excluir(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("ID não pode ser nulo");
        }
        
        if (!experienciaRepository.existsById(id)) {
            throw new RuntimeException("Experiência não encontrada com ID: " + id);
        }
        
        experienciaRepository.deleteById(id);
    }

    @Transactional
    public ExperienciaProfissional atualizar(ExperienciaProfissional experiencia) {
        if (experiencia == null) {
            throw new IllegalArgumentException("Experiência não pode ser nula");
        }
        if (experiencia.getId() == null) {
            throw new IllegalArgumentException("ID da experiência não pode ser nulo");
        }

        // Verifica se a experiência existe
        ExperienciaProfissional existente = experienciaRepository.findById(experiencia.getId())
                .orElseThrow(() -> new RuntimeException("Experiência não encontrada com ID: " + experiencia.getId()));

        // Validação das datas
        validarDatasExperiencia(experiencia);
        
        // Validação dos campos obrigatórios
        validarCamposObrigatorios(experiencia);

        // Mantém o relacionamento com o egresso original
        experiencia.setEgresso(existente.getEgresso());

        // Calcula e atualiza o tempo de trabalho
        experiencia.setTempoTrabalho(experiencia.calcularTempoTrabalho());

        return experienciaRepository.save(experiencia);
    }

    // Métodos auxiliares de validação
    private void validarDatasExperiencia(ExperienciaProfissional experiencia) {
        if (experiencia.getDataInicio() == null) {
            throw new IllegalArgumentException("Data de início é obrigatória");
        }
        
        // Verifica se a data de início não é no futuro
        if (experiencia.getDataInicio().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Data de início não pode ser no futuro");
        }
        
        // Se houver data final, valida se é posterior à data de início
        if (experiencia.getDataFim() != null) {
            if (experiencia.getDataFim().isBefore(experiencia.getDataInicio())) {
                throw new IllegalArgumentException("Data final não pode ser anterior à data de início");
            }
            // Verifica se a data final não é no futuro (opcional, dependendo dos requisitos)
            if (experiencia.getDataFim().isAfter(LocalDate.now())) {
                throw new IllegalArgumentException("Data final não pode ser no futuro");
            }
        }
    }

    private void validarCamposObrigatorios(ExperienciaProfissional experiencia) {
        if (experiencia.getCargo() == null || experiencia.getCargo().isBlank()) {
            throw new IllegalArgumentException("Cargo é obrigatório");
        }
        if (experiencia.getEmpresa() == null || experiencia.getEmpresa().isBlank()) {
            throw new IllegalArgumentException("Empresa é obrigatória");
        }
    }
}