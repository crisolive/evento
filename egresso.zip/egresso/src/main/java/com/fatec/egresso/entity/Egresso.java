package com.fatec.egresso.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Egresso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nomeCompleto;
    private int idade;
    private String curso;
    private int anoConclusao;
    private String linkedin;
    private String github;
    private String letters;
    private String comentarioFatec;
    private String comentarioLivre;
    private String foto;

    @Column(nullable = false, columnDefinition = "boolean default false")
    private boolean concordaTermos;

    @Column(name = "data_aceite_termo")
    private LocalDateTime dataAceiteTermo;

    private boolean dadosPublicos;
    private boolean aprovado;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String senha;

    @Column(nullable = false)
    private boolean emailConfirmado = false;

    @Column(name = "token_confirmacao")
    private String tokenConfirmacao;

    @Column(unique = true, nullable = false)
    private String cpf; // ✅ CPF adicionado

    @OneToMany(mappedBy = "egresso", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<ExperienciaProfissional> experiencias = new ArrayList<>();

    // Métodos helpers
    public void adicionarExperiencia(ExperienciaProfissional experiencia) {
        experiencias.add(experiencia);
        experiencia.setEgresso(this);
    }

    public void removerExperiencia(ExperienciaProfissional experiencia) {
        experiencias.remove(experiencia);
        experiencia.setEgresso(null);
    }
}
